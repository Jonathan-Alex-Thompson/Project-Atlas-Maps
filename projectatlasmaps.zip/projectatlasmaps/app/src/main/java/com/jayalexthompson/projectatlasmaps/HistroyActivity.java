package com.jayalexthompson.projectatlasmaps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class HistroyActivity extends AppCompatActivity {

    //fix this, check why its not selecting from that file
    TextView tripShow;
    Button returnction;
    FirebaseFirestore database = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_histroy);
        tripShow = findViewById(R.id.trip_display);

        returnction = findViewById(R.id.returnAction);
        returnction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mappingPage = new Intent(HistroyActivity.this, DashboardActivity.class);
                startActivity(mappingPage);
            }
        });

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {

            //locate specific user details
            DocumentReference docRef = database.collection("app_trips").document(FirebaseAuth.getInstance().getCurrentUser().getUid());

            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {

                            document.getData();

                            //check if user has filled in all metrics
                            if (document.get("email") != null) {


                                String Display = document.get("start").toString()+ "\n" + document.get("end").toString()+ "\n" + document.get("distance").toString()+ "\n" + document.get("time").toString()+ "\n" +document.get("date").toString()+ "\n" ;

                                tripShow.setText(Display);

                            }else{
                                tripShow.setText("No trips saved yet, please save a trip to see the history");
                            }
                        }else{
                            tripShow.setText("No trip history exists");
                        }
                    }
                }
            });
        }
    }
}
