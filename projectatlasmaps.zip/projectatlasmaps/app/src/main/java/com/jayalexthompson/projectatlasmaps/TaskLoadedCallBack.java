package com.jayalexthompson.projectatlasmaps;

public interface TaskLoadedCallBack {
    void onTaskDone(Object... values);}
